import streamlit as st
import pandas as pd
import pickle
import os

st.set_page_config(page_title="Fake News Detector", page_icon="📰")

st.title("📰 Fake News Detection System")
st.write("Check whether a news article is **Real or Fake** using Machine Learning.")

# --- Train model if not saved ---
if not os.path.exists("model.pkl"):

    fake = pd.read_csv("Fake.csv")
    real = pd.read_csv("True.csv")

    fake["label"] = 0
    real["label"] = 1

    data = pd.concat([fake, real], axis=0)
    data = data.sample(frac=1).reset_index(drop=True)

    data = data[["text", "label"]]

    from sklearn.model_selection import train_test_split
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression

    x = data["text"]
    y = data["label"]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

    vectorizer = TfidfVectorizer(stop_words="english", max_df=0.7)
    xv_train = vectorizer.fit_transform(x_train)

    model = LogisticRegression()
    model.fit(xv_train, y_train)

    # Save model
    pickle.dump(model, open("model.pkl", "wb"))
    pickle.dump(vectorizer, open("vectorizer.pkl", "wb"))

# --- Load model ---
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

# --- User Input ---
user_input = st.text_area("Enter News Article Text")

if st.button("Check News"):
    if user_input.strip() == "":
        st.warning("⚠️ Please enter some text")
    else:
        input_data = vectorizer.transform([user_input])
        prediction = model.predict(input_data)

        if prediction[0] == 0:
            st.error("❌ This is Fake News")
        else:
            st.success("✅ This is Real News")
